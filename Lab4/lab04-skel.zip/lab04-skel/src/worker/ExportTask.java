package worker;

import java.util.List;

import javax.swing.SwingWorker;

public class ExportTask extends SwingWorker<Integer, Integer> {
	  private static final int DELAY = 1000;

	  public ExportTask() {
	  }

	  @Override
	  protected Integer doInBackground() throws Exception {
		// TODO 3.2
		return 0;
	  }
	   
	  protected void process(List<Integer> chunks) {
	   // TODO 3.3 - print values received
	  }

	  @Override
	  protected void done() {
	    if (isCancelled())
	      System.out.println("Cancelled !");
	    else
	      System.out.println("Done !");
	  }
	}