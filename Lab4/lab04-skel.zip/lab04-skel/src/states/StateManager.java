package states;
import app.Mediator;


public class StateManager {
	private State currentState;

	public StateManager(Mediator med) {
	}

	public void setRectangleState() {
		//TODO 2.4
		//set current state as rectangle state
	}

	public void setCircleState() {
		//TODO 2.4
		//set current state as circle state
	}

	public void mouseDown(int x, int y) {
		//TODO 2.4
		//perform mouseDown on the currentState of the manager
	}

	public void mouseUp(int x, int y) {
		//TODO 2.4
		//perform mouseUp on the currentState of the manager
	}

}